﻿using FlashFindWinDemo.AssistUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlashFindWinDemo.ListViewUtils
{
    public class TagsListViewVirtualMode
    {
        public ListView listview;

        public TagsListViewVirtualMode(ListView listview)
        {
            this.listview = listview;
            initVirtualMode();
        }

        public void initVirtualMode()
        {
            this.CurrentCacheItemsSource = new List<ListViewItem>();
            LoadListViewItems(this.CurrentCacheItemsSource);
        }

        #region 虚拟模式

        public List<ListViewItem> CurrentCacheItemsSource
        {
            get;
            private set;
        }

        private void LoadListViewItems(List<ListViewItem> items)
        {
            listview.Items.Clear();
            listview.VirtualListSize = items.Count;
            listview.VirtualMode = true;
            listview.RetrieveVirtualItem += new RetrieveVirtualItemEventHandler(listView_RetrieveVirtualItem);
        }

        void listView_RetrieveVirtualItem(object sender, RetrieveVirtualItemEventArgs e)
        {
            if (this.CurrentCacheItemsSource == null || this.CurrentCacheItemsSource.Count == 0)
            {
                return;
            }

            e.Item = this.CurrentCacheItemsSource[e.ItemIndex];
            if (e.ItemIndex == this.CurrentCacheItemsSource.Count)
            {
                this.CurrentCacheItemsSource = null;
            }
        }

        #endregion


        /// <summary>
        /// listview行数
        /// </summary>
        static int listViewCount = 0;
        /// <summary>
        /// listview上次行数 用于滚动条往下滑
        /// </summary>
        static int lastListViewCount = 0;

        /// <summary>
        /// 添加数据到listview
        /// </summary>
        public void add(string tagsID, string voltage, string ver, string rssi,
            string beep, string flash, string colorsState, string keyState, string colorBit)
        {
            lock (this)
            {
                ListViewItem item = new ListViewItem((listViewCount + 1).ToString("D6"));
                item.SubItems.Add(tagsID);//灯条号
                item.SubItems.Add(voltage + "mV");//电压
                item.SubItems.Add(ver);//版本
                item.SubItems.Add(rssi);//信号强度

                if (beep == "0" && flash == "0" && colorsState == "0" && keyState == "0"
                    && colorBit == "00000000")//无动作
                {
                    item.SubItems.Add("无动作");//灯条动作
                }
                else
                {
                    if (keyState == "1" || keyState == "2")
                    {
                        item.SubItems.Add(tools.getKeyStateString(keyState));
                    }
                    else
                    {
                        item.SubItems.Add(tools.getBeepString(beep)
                            + "-" + tools.getFlashString(flash)
                            + "-" + tools.getColorsStateString(colorsState)
                            + "-" + tools.getColorString(colorBit));
                    }
                }

                item.SubItems.Add(tools.getDateTime());//盘点时间

                listViewCount++;
                CurrentCacheItemsSource.Add(item);
            }
        }


        /// <summary>
        /// 清除
        /// </summary>
        public void clear()
        {
            listViewCount = lastListViewCount = 0;
            listview.VirtualListSize = 0;
            this.CurrentCacheItemsSource.Clear();
            listview.Items.Clear();
        }


        /// <summary>
        /// 刷新
        /// </summary>
        public void refresh()
        {
            listview.VirtualListSize = CurrentCacheItemsSource.Count;
            listview.Invalidate();

            if (lastListViewCount != this.listview.Items.Count)
            {
                if (this.listview.Items.Count > 1) this.listview.Items[this.listview.Items.Count - 1].EnsureVisible();
                lastListViewCount = this.listview.Items.Count;
            }
        }


        /// <summary>
        /// 检查灯条信息是否已存在于列表
        /// </summary>
        /// <returns></returns>
        public bool checkTagExist(string tagsID)
        {
            bool isExist = false;
            foreach (ListViewItem viewitem in this.CurrentCacheItemsSource)
            {
                if (viewitem.SubItems[1].Text == tagsID)
                {
                    isExist = true;
                    break;
                }
            }
            return isExist;
        }


    }
}
