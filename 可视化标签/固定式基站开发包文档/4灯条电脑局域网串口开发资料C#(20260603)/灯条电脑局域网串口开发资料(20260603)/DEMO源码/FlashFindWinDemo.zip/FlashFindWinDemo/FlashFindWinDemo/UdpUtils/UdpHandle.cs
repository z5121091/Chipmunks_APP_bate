﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace FlashFindWinDemo.UdpUtils
{
    public class UdpHandle
    {
        /// <summary>
        /// 存储所有网卡的UDP监听客户端
        /// </summary>
        private UdpClient[] udpClientArray;

        /// <summary>
        /// 发送目标：广播地址
        /// </summary>
        private readonly IPEndPoint targetIpe = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 9002);

        /// <summary>
        /// 线程退出标记
        /// </summary>
        private bool isListening = false;

        #region UDP接收消息事件
        public event EventHandler<UdpRecvMsgEventArgs> UdpRecvMsgEvent;

        public class UdpRecvMsgEventArgs : EventArgs
        {
            public string msg;
            public IPEndPoint remoteEndPoint; // 发送方IP+端口

            public UdpRecvMsgEventArgs(string msg, IPEndPoint remote)
            {
                this.msg = msg;
                this.remoteEndPoint = remote;
            }
        }

        private void OnUdpMessageReceived(UdpRecvMsgEventArgs e)
        {
            UdpRecvMsgEvent?.Invoke(this, e);
        }
        #endregion

        /// <summary>
        /// 启动UDP监听（支持单播+广播）
        /// </summary>
        public bool startUdp(int listenPort)
        {
            try
            {
                // 获取本机所有IPv4地址
                string[] ipStrArray = GetNetIP();
                udpClientArray = new UdpClient[ipStrArray.Length];
                isListening = true;

                for (int i = 0; i < ipStrArray.Length; i++)
                {
                    // 绑定本机IP+端口（这样才能收到定向发给这个IP的报文）
                    IPEndPoint localEp = new IPEndPoint(IPAddress.Parse(ipStrArray[i]), listenPort);
                    udpClientArray[i] = new UdpClient(localEp);

                    // 为每个客户端启动异步接收
                    StartReceiveAsync(udpClientArray[i]);
                }

                return true;
            }
            catch
            {
                stopUdp();
                return false;
            }
        }

        /// <summary>
        /// 停止UDP
        /// </summary>
        public void stopUdp()
        {
            isListening = false;

            if (udpClientArray == null) return;

            foreach (var client in udpClientArray)
            {
                try
                {
                    client.Close();
                }
                catch { }
            }

            udpClientArray = null;
        }

        /// <summary>
        /// 广播发送消息
        /// </summary>
        public bool sendMsg(string msg)
        {
            try
            {
                byte[] data = Encoding.UTF8.GetBytes(msg);
                foreach (var client in udpClientArray)
                {
                    client.Send(data, data.Length, targetIpe);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        #region 核心：异步接收（每个UDP客户端独立监听，无冲突）
        private void StartReceiveAsync(UdpClient client)
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                IPEndPoint remoteEp = new IPEndPoint(IPAddress.Any, 0);
                while (isListening)
                {
                    try
                    {
                        // 阻塞接收数据
                        byte[] buffer = client.Receive(ref remoteEp);
                        if (buffer == null || buffer.Length == 0) continue;

                        // 解码并触发事件
                        string msg = Encoding.UTF8.GetString(buffer);
                        OnUdpMessageReceived(new UdpRecvMsgEventArgs(msg, remoteEp));
                    }
                    catch
                    {
                        // 关闭时会触发异常，直接退出循环
                        break;
                    }
                }
            });
        }
        #endregion

        /// <summary>
        /// 获取本机所有IPv4地址
        /// </summary>
        private string[] GetNetIP()
        {
            var ipList = new List<string>();
            IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());

            foreach (IPAddress ip in hostEntry.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork) // IPv4
                {
                    ipList.Add(ip.ToString());
                }
            }

            // 兜底
            if (ipList.Count == 0)
            {
                ipList.Add("127.0.0.1");
            }

            return ipList.ToArray();
        }
    }
}