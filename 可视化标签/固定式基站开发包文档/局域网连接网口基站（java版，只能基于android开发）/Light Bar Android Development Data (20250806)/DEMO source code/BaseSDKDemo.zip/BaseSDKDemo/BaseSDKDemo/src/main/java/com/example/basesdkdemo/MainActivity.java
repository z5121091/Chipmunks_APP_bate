package com.example.basesdkdemo;

import com.example.basesdk.BaseReader;
import com.xuexiang.xqrcode.XQRCode;
import com.xuexiang.xui.utils.WidgetUtils;
import com.xuexiang.xui.widget.dialog.MiniLoadingDialog;
import com.xuexiang.xui.widget.dialog.materialdialog.DialogAction;
import com.xuexiang.xui.widget.dialog.materialdialog.MaterialDialog;
import com.xuexiang.xui.widget.spinner.materialspinner.MaterialSpinner;
import com.xuexiang.xui.widget.textview.LoggerTextView;

import DemoUtils.Conversion;
import RfidUtils.HandlerBaseMsgLog;
import RfidUtils.HandlerBaseStateChangeLog;
import ScanCodeUtils.CustomCaptureActivity;
import XuiUtils.DateUtils;
import XuiUtils.XToastUtils;
import uhf.Types;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.IllegalFormatCodePointException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity implements View.OnClickListener {

    public static String TAG = "BaseSDKDemo";

	public static Context context;

	/**
	 * Base station library operation class (instantiate a global call)
	 */
	public static BaseReader baseReader;

	//Page control
	private TextView tV_BaseSN,tV_BaseState;
	private CheckBox cB_BeepState,cB_LightState;
	private TextView tV_TagsWorkTime,tV_TagsWorkTimeUnit,tV_TagsIntervalTime,tV_TagsIntervalTimeUnit;
	private RadioButton rB_RedLight,rB_YellowLight,rB_BlueLight,rB_GreenLight,rB_CyanLight,rB_WhiteLight,rB_PurpleLight;
	private EditText tagsWorkTimeText,tagsIntervalTimeText,baseTimeText,countText,totalNumText;
	private Button baseConnectActionBtn,setAcoustOpticTagsWorkBtn,setAcoustOpticTagsStopBtn,setAllAcoustOpticTagsWorkBtn,
			setAllAcoustOpticTagsStopBtn,multiAcoustOpticTagsBtn,tagGroupBtn,scanBtn,clearBtn,tagSleepBtn;
	private EditText scanResultText;
	private LoggerTextView logger;

	/**
	 * Pop up loading (connected for use)
	 */
	public static MiniLoadingDialog mMiniLoadingDialog;

	/////////////////   Group related   /////////////////

	public Dialog tagGroupCustomDialog;

	public EditText label1Text,label2Text,label3Text;
	public MaterialSpinner sp_label1Rule,sp_label2Rule,sp_label3Rule;

	public Button updateTagGroupBtn,setGroupTagsWorkBtn;

	/////////////////   Light strip sleep related   /////////////////

	public Dialog tagSleepCustomDialog;

	public EditText sleepTimeText;

	public Button setTagSleepTimeBtn;

	/////////////////   Inventory related   /////////////////

	/**
	 * Inventory Light Bar Information List
	 */
	public static List<String> multiTagsList;

	public Dialog multiCustomDialog;
	public TextView tV_MultiRemainingTime,tV_MultiTagsNum;
	public Button confirmBtn;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initView();
		initBaseSDK();
	}


	/**
	 * Initialize loading interface
	 */
	public void initView()
	{
		context = this;

		//Current base station SN
		tV_BaseSN = (TextView)findViewById(R.id.tV_BaseSN);
		//Connection status
		tV_BaseState = (TextView)findViewById(R.id.tV_BaseState);
		//Connect or disconnect the base station
		baseConnectActionBtn = (Button) findViewById(R.id.baseConnectActionBtn);
		baseConnectActionBtn.setOnClickListener(this);
		//Lighting time&flash interval
		tagsWorkTimeText = (EditText) findViewById(R.id.tB_TagsWorkTime);
		tagsIntervalTimeText = (EditText) findViewById(R.id.tB_TagsIntervalTime);
		tV_TagsWorkTime = (TextView)findViewById(R.id.tV_TagsWorkTime);
		tV_TagsWorkTimeUnit = (TextView)findViewById(R.id.tV_TagsWorkTimeUnit);
		tV_TagsIntervalTime = (TextView)findViewById(R.id.tV_TagsIntervalTime);
		tV_TagsIntervalTimeUnit = (TextView)findViewById(R.id.tV_TagsIntervalTimeUnit);
		//Sound On
		cB_BeepState = (CheckBox)findViewById(R.id.cB_BeepState);
		//Flash reminder
		cB_LightState = (CheckBox)findViewById(R.id.cB_LightState);
		cB_LightState.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// Write the processing logic for click events here
				if (isChecked) //flash
				{
//                    tagsWorkTimeText.setEnabled(false);
					tagsIntervalTimeText.setEnabled(true);

//                    tV_TagsWorkTime.setTextColor(Color.parseColor("#dbdbdb"));//Gray
//                    tV_TagsWorkTimeUnit.setTextColor(Color.parseColor("#dbdbdb"));
//                    tagsWorkTimeText.setTextColor(Color.parseColor("#dbdbdb"));

					tV_TagsIntervalTime.setTextColor(Color.parseColor("#4f68b0"));
					tV_TagsIntervalTimeUnit.setTextColor(Color.parseColor("#4f68b0"));
					tagsIntervalTimeText.setTextColor(Color.parseColor("#4f68b0"));
				}
				else//Long term illumination
				{
//                    tagsWorkTimeText.setEnabled(true);
					tagsIntervalTimeText.setEnabled(false);

//                    tV_TagsWorkTime.setTextColor(Color.parseColor("#4f68b0"));
//                    tV_TagsWorkTimeUnit.setTextColor(Color.parseColor("#4f68b0"));
//                    tagsWorkTimeText.setTextColor(Color.parseColor("#4f68b0"));

					tV_TagsIntervalTime.setTextColor(Color.parseColor("#dbdbdb"));//Gray
					tV_TagsIntervalTimeUnit.setTextColor(Color.parseColor("#dbdbdb"));
					tagsIntervalTimeText.setTextColor(Color.parseColor("#dbdbdb"));
				}
			}
		});

		//Color selection
		rB_RedLight = (RadioButton) findViewById(R.id.rB_RedLight);
		rB_YellowLight = (RadioButton) findViewById(R.id.rB_YellowLight);
		rB_BlueLight = (RadioButton) findViewById(R.id.rB_BlueLight);
		rB_GreenLight = (RadioButton) findViewById(R.id.rB_GreenLight);
		rB_CyanLight = (RadioButton) findViewById(R.id.rB_CyanLight);
		rB_WhiteLight = (RadioButton) findViewById(R.id.rB_WhiteLight);
		rB_PurpleLight = (RadioButton) findViewById(R.id.rB_PurpleLight);
		//Light up
		setAcoustOpticTagsWorkBtn = (Button) findViewById(R.id.setAcoustOpticTagsWorkBtn);
		setAcoustOpticTagsWorkBtn.setOnClickListener(this);
        //Stop
		setAcoustOpticTagsStopBtn = (Button) findViewById(R.id.setAcoustOpticTagsStopBtn);
		setAcoustOpticTagsStopBtn.setOnClickListener(this);
		//All lights up
		setAllAcoustOpticTagsWorkBtn = (Button) findViewById(R.id.setAllAcoustOpticTagsWorkBtn);
		setAllAcoustOpticTagsWorkBtn.setOnClickListener(this);
		//Stop all
		setAllAcoustOpticTagsStopBtn = (Button) findViewById(R.id.setAllAcoustOpticTagsStopBtn);
		setAllAcoustOpticTagsStopBtn.setOnClickListener(this);
		//Interval, frequency, total number (inventory parameters)
		baseTimeText = (EditText) findViewById(R.id.baseTimeText);
		countText = (EditText) findViewById(R.id.countText);
		totalNumText = (EditText) findViewById(R.id.totalNumText);
		//Inventory
		multiAcoustOpticTagsBtn = (Button) findViewById(R.id.multiAcoustOpticTagsBtn);
		multiAcoustOpticTagsBtn.setOnClickListener(this);
		//Group related
		tagGroupBtn = (Button) findViewById(R.id.tagGroupBtn);
		tagGroupBtn.setOnClickListener(this);
		//Scan the code
		scanBtn = (Button) findViewById(R.id.scanBtn);
		scanBtn.setOnClickListener(this);
		//clear
		clearBtn = (Button) findViewById(R.id.clearBtn);
		clearBtn.setOnClickListener(this);
		//Light strip sleep
		tagSleepBtn = (Button) findViewById(R.id.tagSleepBtn);
		tagSleepBtn.setOnClickListener(this);
		//scanning results
		scanResultText = (EditText) this.findViewById(R.id.scanResultText);
		scanResultText.setMovementMethod(ScrollingMovementMethod.getInstance());
		scanResultText.setScrollbarFadingEnabled(false);//If the content exceeds the limit, the scrollbar will always display
		//Information output
		logger = (LoggerTextView) this.findViewById(R.id.logger);
		//Set custom log format here
		logger.setLogFormatter(new LoggerTextView.ILogFormatter() {
			@Override
			public String format(String logContent, LoggerTextView.LogType logType) {
				return DateUtils.getNowString(new SimpleDateFormat("[HH:mm:ss]")) + logContent;
			}
		});
	}


	/**
	 * Initialize base station library
	 */
	public void initBaseSDK()
	{
		baseReader = new BaseReader();
		subscribeBaseMsgLog();
		subscribeBaseStateChangeLog();

		logger.logNormal( "");
		logger.logNormal( "SDK Version��" + baseReader.sdkVersion());
	}


	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
			case R.id.baseConnectActionBtn://Connect or disconnect the base station
				baseConnectActionMethod();
				break;
			case R.id.setAcoustOpticTagsWorkBtn://Light up
				setAcoustOpticTagsWork();
				break;
			case R.id.setAcoustOpticTagsStopBtn://stop
				setAcoustOpticTagsStop();
				break;
			case R.id.setAllAcoustOpticTagsWorkBtn://All lights up
				setAllAcoustOpticTagsWork();
				break;
			case R.id.setAllAcoustOpticTagsStopBtn://stop all
				setAllAcoustOpticTagsStop();
				break;
			case R.id.multiAcoustOpticTagsBtn://Inventory
				logger.clearLog();
//				logger.logNormal( "");
				multiTagsBtnMethod();
				break;
			case R.id.tagGroupBtn://Group related
				showTagGroupDialog();
				break;
			case R.id.scanBtn://Scan the code
				scanQRCode();
				break;
			case R.id.clearBtn://clear
				scanResultText.setText("");
				logger.clearLog();
//				logger.logNormal( "");
				break;
			case R.id.tagSleepBtn://Light strip sleep
				showTagSleepDialog();
				break;
		}
	}


	/**
	 * Connect or disconnect the base station
	 */
	public void baseConnectActionMethod()
	{
		String btnStr = baseConnectActionBtn.getText().toString();
		if(btnStr.equals("Connect base station"))
		{
//			baseReader.connectBase("QJ000000000001");
			baseReader.connectBase();

			baseConnectActionBtn.setText("Disconnect the connection");
			baseConnectActionBtn.setBackgroundResource(R.drawable.button_disconnect_click_bg);
			showLoadingDialog("Searching for base station and connecting, please wait...");
		}
		else
		{
			baseReader.disConnectBase();

			baseConnectActionBtn.setText("Connect base station");
			baseConnectActionBtn.setBackgroundResource(R.drawable.button_connect_click_bg);
			resetBaseMessageText();
		}
	}


	/**
	 * Reset the display of base station information
	 */
	public void resetBaseMessageText()
	{
		tV_BaseSN.setText("-");
		tV_BaseSN.setTextColor(Color.parseColor("#0061b2"));
		tV_BaseState.setText("-");
		tV_BaseState.setTextColor(Color.parseColor("#0061b2"));
	}


	/**
	 * Light up
	 */
	public void setAcoustOpticTagsWork()
	{
		try
		{
			//lighting
			byte rgb = GetRgbValue();
			//sound
			byte beep = 0x00;
			if (cB_BeepState.isChecked()) beep = 0x01;
			//Working time
			byte workTime = getWorkTime();
			//Interval time
			byte intervalTime = getIntervalTime();

			//Tag Code
			String tagsCode = scanResultText.getText().toString();
			//Hexadecimal array of ID numbers for sound and light tags
			List<byte[]> acoustOpticTagsIDList = getAcoustOpticTagsIDList(tagsCode);

			baseReader.SetAcoustOpticTagsWork(rgb, beep, acoustOpticTagsIDList, workTime, intervalTime);
		}
		catch(Exception ex)
		{
			XToastUtils.error("Please check the time and scan the code for any errors and try again!");
		}
	}


	/**
	 * Stop
	 */
	public void setAcoustOpticTagsStop()
	{
		try
		{
			//lighting
			byte rgb = 0x08;//Default value: No light on
			//sound
			byte beep = 0x00;//Not making a sound
			//Working time
			byte workTime = getWorkTime();
			//Interval time
			byte intervalTime = getIntervalTime();

			//Tag Code
			String tagsCode = scanResultText.getText().toString();
			//Hexadecimal array of ID numbers for sound and light tags
			List<byte[]> acoustOpticTagsIDList = getAcoustOpticTagsIDList(tagsCode);

			baseReader.SetAcoustOpticTagsWork(rgb, beep, acoustOpticTagsIDList, workTime, intervalTime);
		}
		catch(Exception ex)
		{
			XToastUtils.error("Please check the time and scan the code for any errors and try again!");
		}
	}


	/**
	 * All lights up
	 */
	public void setAllAcoustOpticTagsWork()
	{
		try
		{
			//lighting
			byte rgb = GetRgbValue();
			//sound
			byte beep = 0x00;
			if (cB_BeepState.isChecked()) beep = 0x01;
			//Working time
			byte workTime = getWorkTime();
			//Interval time
			byte intervalTime = getIntervalTime();

			//Hexadecimal array of ID numbers for sound and light tags
			List<byte[]> acoustOpticTagsIDList = getAcoustOpticTagsIDList("0000000000");

			baseReader.SetAcoustOpticTagsWork(rgb, beep, acoustOpticTagsIDList, workTime, intervalTime);
		}
		catch(Exception ex)
		{
			XToastUtils.error(ex + "");
		}
	}


	/**
	 * Stop all
	 */
	public void setAllAcoustOpticTagsStop()
	{
		try
		{
			//lighting
			byte rgb = 0x08;//Default value: No light on
			//sound
			byte beep = 0x00;//Not making a sound
			//Working time
			byte workTime = getWorkTime();
			//Interval time
			byte intervalTime = getIntervalTime();

			//Hexadecimal array of ID numbers for sound and light tags
			List<byte[]> acoustOpticTagsIDList = getAcoustOpticTagsIDList("0000000000");

			baseReader.SetAcoustOpticTagsWork(rgb, beep, acoustOpticTagsIDList, workTime, intervalTime);
		}
		catch(Exception ex)
		{
			XToastUtils.error(ex + "");
		}
	}


	/**
	 * Obtain the corresponding color values
	 * @return
	 */
	public byte GetRgbValue()
	{
		//lighting
		byte rgb = 0x00;
		if (cB_LightState.isChecked())//Check the flashing light
		{
			if (rB_RedLight.isChecked()) rgb = 0x04;
			else if (rB_YellowLight.isChecked()) rgb = 0x06;
			else if (rB_BlueLight.isChecked()) rgb = 0x01;
			else if (rB_GreenLight.isChecked()) rgb = 0x02;
			else if (rB_CyanLight.isChecked()) rgb = 0x03;
			else if (rB_WhiteLight.isChecked()) rgb = 0x07;
			else if (rB_PurpleLight.isChecked()) rgb = 0x05;
		}
		else//Do not check the long light option, set the highest bit to 1
		{
			if (rB_RedLight.isChecked()) rgb = (byte)0x84;
			else if (rB_YellowLight.isChecked()) rgb = (byte)0x86;
			else if (rB_BlueLight.isChecked()) rgb = (byte)0x81;
			else if (rB_GreenLight.isChecked()) rgb = (byte)0x82;
			else if (rB_CyanLight.isChecked()) rgb = (byte)0x83;
			else if (rB_WhiteLight.isChecked()) rgb = (byte)0x87;
			else if (rB_PurpleLight.isChecked()) rgb = (byte)0x85;
		}
		return rgb;
	}

	/**
	 * Obtain the duration value of the light on
	 * @return
	 */
	public byte getWorkTime()
	{
		byte workTime = (byte)60;
		if(tagsWorkTimeText.getText().toString().equals("")) tagsWorkTimeText.setText("60");
		int workTimeValue = Integer.parseInt(tagsWorkTimeText.getText().toString());
		if (workTimeValue < 10) tagsWorkTimeText.setText("10");//Minimum value of 10
		else if (workTimeValue > 765) tagsWorkTimeText.setText("765");//Maximum value 765
		workTimeValue = Integer.parseInt(tagsWorkTimeText.getText().toString()) / 3;
		workTime = (byte)workTimeValue;
		return workTime;
	}


	/**
	 * Obtain flash interval
	 * @return
	 */
	public byte getIntervalTime()
	{
		byte intervalTime = (byte)1;
		if(tagsIntervalTimeText.getText().toString().equals("")) tagsIntervalTimeText.setText("1");
		int intervalTimeValue = Integer.parseInt(tagsIntervalTimeText.getText().toString());
		if (intervalTimeValue > 25) tagsIntervalTimeText.setText("25");//Maximum value 25
		intervalTimeValue = Integer.parseInt(tagsIntervalTimeText.getText().toString()) * 10;
		intervalTime = (byte)intervalTimeValue;
		return intervalTime;
	}


	/**
	 * Retrieve the hexadecimal array of sound and light tag ID numbers (the original scanned data consists of 10 digit length characters)
	 * @return
	 */
	public List<byte[]> getAcoustOpticTagsIDList(String tagsCode)
	{
		String[] tagsCodeArray = tagsCode.split("\\n"); //Use '\ \ n' to represent line breaks

		List<byte[]> acoustOpticTagsIDList = new ArrayList<byte[]>();

		byte[] sourcedata;
		byte[] enddata;
		String singleTagsCode = "";
		for (int i = 0; i < tagsCodeArray.length; i++)
		{
			singleTagsCode = tagsCodeArray[i].trim().replace(" ","");
			if(singleTagsCode.length() > 10) singleTagsCode = singleTagsCode.substring(singleTagsCode.length() - 10,singleTagsCode.length());
			sourcedata = Conversion.longToBytes(Long.parseLong(singleTagsCode));
			enddata = new byte[] { sourcedata[4],sourcedata[5],sourcedata[6],sourcedata[7] };
			acoustOpticTagsIDList.add(enddata);
		}
		return acoustOpticTagsIDList;
	}


	///////////////////   Group related start   ///////////////////

	/**
	 * Load group related function pop-up window
	 */
	public void showTagGroupDialog()
	{
		tagGroupCustomDialog = new Dialog(context);
		tagGroupCustomDialog.setContentView(R.layout.dialog_taggroup);

		label1Text = tagGroupCustomDialog.findViewById(R.id.label1Text);
		label2Text = tagGroupCustomDialog.findViewById(R.id.label2Text);
		label3Text = tagGroupCustomDialog.findViewById(R.id.label3Text);
		sp_label1Rule = tagGroupCustomDialog.findViewById(R.id.sp_label1Rule);
		sp_label2Rule = tagGroupCustomDialog.findViewById(R.id.sp_label2Rule);
		sp_label3Rule = tagGroupCustomDialog.findViewById(R.id.sp_label3Rule);

		updateTagGroupBtn = tagGroupCustomDialog.findViewById(R.id.updateTagGroupBtn);
		updateTagGroupBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				updateTagGroup();
			}
		});

		setGroupTagsWorkBtn = tagGroupCustomDialog.findViewById(R.id.setGroupTagsWorkBtn);
		setGroupTagsWorkBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				setGroupTagsWork();
			}
		});

//		tagGroupCustomDialog.setCancelable(false);//Do not allow clicking on blank or return button to cancel
		tagGroupCustomDialog.show();
	}


	/**
	 * Update the grouping of light strips
	 */
	public void updateTagGroup()
	{
		try
		{
			//Tag Code
			String tagsCode = scanResultText.getText().toString();
			//Hexadecimal array of ID numbers for sound and light tags
			List<byte[]> acoustOpticTagsIDList = getAcoustOpticTagsIDList(tagsCode);
			if(acoustOpticTagsIDList.size() != 1)
			{
				XToastUtils.error("Please ensure that there is only one light number in the scanning result and try again!");
				return;
			}

			if(label1Text.getText().toString().length() != 2)
			{
				XToastUtils.error("The information of the courier company needs to be filled in with hexadecimal characters of length 2!");
				return;
			}

			if(label2Text.getText().toString().length() != 4)
			{
				XToastUtils.error("The shelf number information needs to be filled in with hexadecimal characters of length 4!");
				return;
			}

			if(label3Text.getText().toString().length() != 8)
			{
				XToastUtils.error("Time information needs to be filled in with hexadecimal characters of length 8!");
				return;
			}

			//Group light bar number
			byte[] tagID = acoustOpticTagsIDList.get(0);
			//Group Label 1
			byte label1 = Conversion.toBytes(label1Text.getText().toString())[0];
			//Group Label 2
			byte[] label2 = Conversion.toBytes(label2Text.getText().toString());
			//Group Label 3
			byte[] label3 = Conversion.toBytes(label3Text.getText().toString());

			baseReader.UpdateAcoustOpticTagsGroup(tagID,label1,label2,label3);
		}
		catch(Exception ex)
		{
			XToastUtils.error(ex + "");
		}
	}


	/**
	 * Light up grouping
	 */
	public void setGroupTagsWork()
	{
		try
		{
			if(label1Text.getText().toString().length() != 2)
			{
				XToastUtils.error("The information of the courier company needs to be filled in with hexadecimal characters of length 2!");
				return;
			}

			if(label2Text.getText().toString().length() != 4)
			{
				XToastUtils.error("The shelf number information needs to be filled in with hexadecimal characters of length 4!");
				return;
			}

			if(label3Text.getText().toString().length() != 8)
			{
				XToastUtils.error("Time information needs to be filled in with hexadecimal characters of length 8!");
				return;
			}

			//Group Label 1
			byte label1 = Conversion.toBytes(label1Text.getText().toString())[0];
			//Group Label 2
			byte[] label2 = Conversion.toBytes(label2Text.getText().toString());
			//Group Label 3
			byte[] label3 = Conversion.toBytes(label3Text.getText().toString());
			//Label 1 Matching Rules
			byte label1Rule = (byte)sp_label1Rule.getSelectedIndex();
			//Label 2 Matching Rules
			byte label2Rule = (byte)sp_label2Rule.getSelectedIndex();
			//Label 3 Matching Rules
			byte label3Rule = (byte)sp_label3Rule.getSelectedIndex();

			//lighting
			byte rgb = GetRgbValue();
			//sound
			byte beep = 0x00;
			if (cB_BeepState.isChecked()) beep = 0x01;
			//Working hours
			byte workTime = getWorkTime();
			//Interval duration
			byte intervalTime = getIntervalTime();

			baseReader.SetGroupAcoustOpticTagsWork(label1,label2,label3,label1Rule,label2Rule,label3Rule,
			                              rgb,beep,workTime,intervalTime);
		}
		catch(Exception ex)
		{
			XToastUtils.error(ex + "");
		}
	}


	///////////////////   Group related ends   ///////////////////

    ///////////////////   Light strip sleep begins   ///////////////////

	/**
	 * Load light bar sleep function pop-up window
	 */
	public void showTagSleepDialog()
	{
		tagSleepCustomDialog = new Dialog(context);
		tagSleepCustomDialog.setContentView(R.layout.dialog_tagsleep);

		sleepTimeText = tagSleepCustomDialog.findViewById(R.id.sleepTimeText);

		setTagSleepTimeBtn = tagSleepCustomDialog.findViewById(R.id.setTagSleepTimeBtn);
		setTagSleepTimeBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				setTagsSleepTime(Integer.parseInt(sleepTimeText.getText().toString()));
			}
		});

//		tagSleepCustomDialog.setCancelable(false);//Do not allow clicking on blank or return button to cancel
		tagSleepCustomDialog.show();
	}


	/**
	 * Set the sleep time for the light bar
	 */
	public void setTagsSleepTime(int sleepTime)
	{
		if(5 <= sleepTime && sleepTime <= 100)
		{
			baseReader.SetTagsSleepTime(sleepTime);
			tagSleepCustomDialog.dismiss();
		}
		else
		{
			XToastUtils.error("Please enter a time value within the range of 5-100!");
		}
	}

    ///////////////////   Light bar sleep ends   ///////////////////

	///////////////////   Inventory related start   ///////////////////

	/**
	 * Inventory button execution function
	 */
	public void multiTagsBtnMethod()
	{
		showMultiDialog();
		multiAcoustOpticTags();
		Log.e(TAG, "Inventory begins");
	}


	/**
	 * Inventory
	 */
	public void multiAcoustOpticTags()
	{
		try
		{
			multiTagsList = new ArrayList<String>();

			//Interval time, minimum value 1000, maximum value 10000
			int baseTimeValue = Integer.parseInt(baseTimeText.getText().toString());
			if (baseTimeValue < 1000) baseTimeText.setText("1000");//Minimum value 1000
			else if (baseTimeValue > 10000) baseTimeText.setText("10000");//Maximum value of 10000
			baseTimeValue = Integer.parseInt(baseTimeText.getText().toString());

			//Number of times, minimum value 1, maximum value 255
			int count = Integer.parseInt(countText.getText().toString());
			if (count < 1) countText.setText("1");//Minimum value 1
			else if (count > 255) countText.setText("255");//Maximum value 255
			count = Integer.parseInt(countText.getText().toString());

			//Total number of times, minimum value 1, maximum value 255
			int totalNum = Integer.parseInt(totalNumText.getText().toString());
			if (totalNum < 1) totalNumText.setText("1");//Minimum value 1
			else if (totalNum > 255) totalNumText.setText("255");//Maximum value 255
			totalNum = Integer.parseInt(totalNumText.getText().toString());

			baseReader.MultiAcoustOpticTags(baseTimeValue, count, totalNum);

			resetMultiRemainingTimeAndStartTimer(baseTimeValue,totalNum);
		}
		catch(Exception ex)
		{
			XToastUtils.error(ex + "");
		}
	}


	/**
	 * Reset the remaining inventory time and start the inventory countdown timer
	 */
	public void resetMultiRemainingTimeAndStartTimer(int baseTimeValue,int totalNum)
	{
		//Inventory time calculation
		int multiTimeForSecond = (1500 + baseTimeValue) * totalNum + 10000 + 10000;
		multiTimeForSecond = (multiTimeForSecond + (multiTimeForSecond / 60000) * 10000) / 1000;
		tV_MultiRemainingTime.setText(multiTimeForSecond + "S");
		startMultiCoundDownTimer();
	}


	/**
	 * Load and display inventory pop-up window
	 */
	public void showMultiDialog()
	{
		if(multiCustomDialog == null)
		{
			multiCustomDialog = new Dialog(context);
			multiCustomDialog.setContentView(R.layout.dialog_multi);
			tV_MultiRemainingTime = multiCustomDialog.findViewById(R.id.tV_MultiRemainingTime);
			tV_MultiTagsNum = multiCustomDialog.findViewById(R.id.tV_MultiTagsNum);

			confirmBtn = multiCustomDialog.findViewById(R.id.confirmBtn);
			confirmBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dismissMultiDialog();
					logger.logNormal("Number of lighting strips in this round:" + multiTagsList.size());
				}
			});

			multiCustomDialog.setCancelable(false);//Do not allow clicking on blank or return button to cancel
			multiCustomDialog.show();
		}
	}


	/**
	 * Close the inventory pop-up window
	 */
	public void dismissMultiDialog()
	{
		if(multiCustomDialog != null)
		{
			multiCustomDialog.dismiss();
			multiCustomDialog = null;
		}
	}


	private Timer mutliCoundDownTimer = new Timer();
	private TimerTask timerTask;
	private boolean isTimerRunning = false;

	/**
	 * Start inventory countdown timer
	 */
	public void startMultiCoundDownTimer()
	{
		if (!isTimerRunning)
		{
			setMultiCoundDownTask();
			//Execute tasks every xx milliseconds, adjustable as needed
			mutliCoundDownTimer.schedule(timerTask, 1000, 1000);
			isTimerRunning = true;
		}
	}

	/**
	 * Stop inventory countdown timer
	 */
	public void stopMultiCoundDownTimer()
	{
		if (isTimerRunning)
		{
			timerTask.cancel();
			isTimerRunning = false;
		}
	}

	/**
	 * Set Timer Task
	 */
	private void setMultiCoundDownTask() {
		timerTask = new TimerTask() {
			@Override
			public void run() {
				mutliCoundDownTimerMethod();
			}
		};
	}


	public void mutliCoundDownTimerMethod()
	{
		this.runOnUiThread(new Runnable() {
			@Override
			public void run() {

				String timeStr = tV_MultiRemainingTime.getText().toString().substring(0,tV_MultiRemainingTime.getText().toString().length() - 1);
				int time = (Integer.parseInt(timeStr) - 1);
				tV_MultiRemainingTime.setText(time + "S");
//				tV_MultiTagsNum.setText(multiTagsList.size() + "");
				if (time == 0)//Inventory completed
				{
					stopMultiCoundDownTimer();
					confirmBtn.setEnabled(true);
					confirmBtn.setBackgroundResource(R.drawable.button_connect_click_bg);
					Log.e(TAG, "Inventory completed");
				}
			}
		});
	}


	/**
	 * Update the statistics of the number of inventory tags
	 */
	public void updateMultiTagsNumMessage(String tagsID)
	{
		if(multiCustomDialog == null) return;//Not in inventory, no information is being counted

		if(multiTagsList.size() == 0)
		{
			multiTagsList.add(tagsID);
			updateMultiTagsNum();
		}
		else
		{
			Boolean isExist = false;
			for(int i = 0;i<multiTagsList.size();i++)
			{
				if(multiTagsList.get(i).equals(tagsID))
				{
					isExist = true;
					break;
				}
			}

			if(!isExist)
			{
				multiTagsList.add(tagsID);
				updateMultiTagsNum();
			}
		}
	}


	/**
	 * Update the number of light bars on the disk with text
	 */
	public void updateMultiTagsNum()
	{
		this.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				tV_MultiTagsNum.setText(multiTagsList.size() + "");
			}
		});
	}


    ///////////////////   Inventory related completion   ///////////////////

	/**
	 * Scan QR code
	 */
	public void scanQRCode()
	{
		CustomCaptureActivity.start(this, 111, R.style.XQRCodeTheme_Custom);
	}

	/**
	 * Receive QR code scanning results
	 * @param requestCode
	 * @param resultCode
	 * @param data
	 */
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		//Processing QR code scanning results
		if (requestCode == 111 && resultCode == RESULT_OK) {
			//Process scan results (displayed on the interface)
			handleScanResult(data);
		}
	}

	/**
	 * Processing QR code scanning results
	 * @param data
	 */
	private void handleScanResult(Intent data) {
		if (data != null) {
			Bundle bundle = data.getExtras();
			if (bundle != null) {
				if (bundle.getInt(XQRCode.RESULT_TYPE) == XQRCode.RESULT_SUCCESS)
				{
					String result = bundle.getString(XQRCode.RESULT_DATA);
					XToastUtils.success("Successfully parsed QR code", Toast.LENGTH_LONG);
					scanResultText.append(result + "\r\n");
				}
				else if (bundle.getInt(XQRCode.RESULT_TYPE) == XQRCode.RESULT_FAILED)
				{
					XToastUtils.error("Failed to parse QR code", Toast.LENGTH_LONG);
				}
			}
		}
	}



	/**
	 * Subscribe to notifications of changes in base station connection status
	 */
	public void subscribeBaseStateChangeLog()
	{
		baseReader.onBaseStateChangeLog = new HandlerBaseStateChangeLog() {
			@Override
			public void baseStateChangeLog(String SN, Boolean isOnLine) {
				// TODO Auto-generated method stub
				Log.e(TAG, "SN=" + SN + ",Connection status=" + isOnLine);
				updateBaseState(SN,isOnLine);
			}
		};
	}


	/**
	 * Subscribe to base station data notifications
	 */
	public void subscribeBaseMsgLog()
	{
		baseReader.onBaseMsgLog= new HandlerBaseMsgLog() {
			@Override
			public void baseMsgLog(String data) {
				// TODO Auto-generated method stub
				Log.i(TAG, "Original data of base station=" + data);
				baseDataHandle(data);
			}
		};
	}


	/**
	 * Update the status of the base station
	 */
	public void updateBaseState(final String SN,final Boolean isOnLine)
	{
		this.runOnUiThread(new Runnable() {
			@Override
			public void run() {

				tV_BaseSN.setText(SN);
				if(isOnLine)
				{
					dismissLoadingDialog();

					tV_BaseState.setText("Online");
					tV_BaseState.setTextColor(Color.parseColor("#0e932e"));
				}
				else
				{
					tV_BaseState.setText("Offline (reconnecting)");
					tV_BaseState.setTextColor(Color.parseColor("#d81e06"));
				}

			}
		});
	}


	/**
	 * Base station data processing
	 */
	public void baseDataHandle(String data)
	{
		String[] result = (data + "," + "0").split("\\,");
		byte type = Conversion.toBytes(result[1])[0];
		switch(type)
		{
			case Types.ACOUSTO_OPTIC_TAGS_WORK://Light up the light bar and respond to the inventory operation (receiving this data indicates that the base station has accepted the command execution)
			case Types.ACOUSTO_OPTIC_TAGS_FUNCTION://Update light bar grouping, light up group light bar response (receiving this data indicates that the base station has accepted the command execution)
				updateControlActionRespond(result);
				break;
			case Types.ACOUSTO_OPTIC_TAGS_ALARM_RESPOND://Light bar information (general)
				updateMultiTagsNumMessage(result[3]);
				updateRecvAcoustOpticTagsAlarmRespond(result);
				break;
			case Types.ACOUSTO_OPTIC_EXPANSION_TAGS_RESPOND://Light bar actively reports information (extension)
				if (result[2].equals("1"))
				{
					switch(result[3])
					{
						case "0"://On/off light strip information
							recvExpansionTagsMessageHandle(result);
							break;
					}
				}
				break;
		}
	}


	/**
	 * Update control result information
	 * @param result
	 */
	public void updateControlActionRespond(final String[] result)
	{
		this.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				String resultMsg = "";
				if (result[2].equals("1")) resultMsg = "Operation successful";
				else resultMsg = "Operation failed";
				logger.logNormal(resultMsg);
			}
		});
	}


	/**
	 * The number of times the light bar information has been printed
	 */
	public static int loggerInputTagsMsgCount = 0;

	/**
	 * Update the low voltage warning information of the sound and light tags
	 * @param result
	 */
	public void updateRecvAcoustOpticTagsAlarmRespond(final String[] result)
	{
		this.runOnUiThread(new Runnable() {
			@Override
			public void run() {

				if(multiCustomDialog != null) return;//During inventory, relevant information is not displayed at the information output

				if(loggerInputTagsMsgCount >= 500)
				{
					logger.clearLog();
					loggerInputTagsMsgCount = 0;
				}

				loggerInputTagsMsgCount++;
				String resultMsg = "";
				if (result[2].equals("1"))
				{
					resultMsg = "Tag[" + result[3] + "]Voltage[" + result[4] + "mv]";
				}
				logger.logWarning(resultMsg);
			}
		});
	}


	/**
	 * The light strip actively reports information (switching value)
	 * @param result
	 */
	public void recvExpansionTagsMessageHandle(final String[] result)
	{
		String message = "Tag[" + result[4] + "]Voltage[" + result[5] + "mv]"
				+ "Hver[" + result[6] + "]Fver[" + result[7] + "]"
				+ "Switch[" + result[15] + result[14] + result[13] + result[12]
				+ result[11] + result[10] + result[9] + result[8] + "]";
		logger.logWarning(message);
	}


	/**
	 * Loading display loading pop-up window
	 * @param msg
	 */
	public static void showLoadingDialog(String msg)
	{
		if(mMiniLoadingDialog == null)
		{
			mMiniLoadingDialog = WidgetUtils.getMiniLoadingDialog(context);
			mMiniLoadingDialog.updateMessage(msg);
			mMiniLoadingDialog.show();
		}
	}


	/**
	 * Close the loading pop-up window
	 */
	public static void dismissLoadingDialog()
	{
		if(mMiniLoadingDialog != null)
		{
			mMiniLoadingDialog.dismiss();
			mMiniLoadingDialog = null;
		}
	}


	/**
	 * Key Capture
	 * @param keyCode
	 * @param event
	 * @return
	 */
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			exit();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}


	/**
	 * Exit software prompt
	 */
	private void exit()
	{
		new MaterialDialog.Builder(MainActivity.this)
			.title("Tip")
			.content("Do you want to exit the software��")
			.positiveText("Yes")
			.negativeText("No")
			.onPositive(new MaterialDialog.SingleButtonCallback() {
				@Override
				public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
					baseReader.disConnectBase();
					System.exit(0);
				}
			})
			.onNegative(new MaterialDialog.SingleButtonCallback() {
				@Override
				public void onClick(MaterialDialog dialog, DialogAction which) {

				}
			})
			.show();
	}

}
