package DemoUtils;

import java.nio.ByteBuffer;

public class Conversion {

    /**
     * Convert long type to byte []
     * @param l
     * @return
     */
    public static byte[] longToBytes(long l){
        //Allocate a buffer in bytes, with one long type occupying 8 bytes, so allocate it as 8
        ByteBuffer byteBuffer = ByteBuffer.allocate(Long.SIZE/Byte.SIZE);
        //Parameter one is the starting position (default is 0 if not specified), and parameter two is the value placed
//        byteBuffer.putLong(0,l);
        byteBuffer.putLong(0,l);
        return byteBuffer.array();
    }



    /**
     * Convert hexadecimal string to byte []
     * @param str
     * @return
     */
    public static byte[] toBytes(String str) {
        if(str == null || str.trim().equals("")) {
            return new byte[0];
        }
        str = str.replace(" ", "");
        byte[] bytes = new byte[str.length() / 2];
        for(int i = 0; i < str.length() / 2; i++) {
            String subStr = str.substring(i * 2, i * 2 + 2);
            bytes[i] = (byte) Integer.parseInt(subStr, 16);
        }
        return bytes;
    }


}
