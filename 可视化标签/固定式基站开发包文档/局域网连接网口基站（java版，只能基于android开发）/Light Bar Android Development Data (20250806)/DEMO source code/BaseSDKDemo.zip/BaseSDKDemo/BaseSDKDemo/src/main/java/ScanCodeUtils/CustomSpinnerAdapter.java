package ScanCodeUtils;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomSpinnerAdapter extends ArrayAdapter<String> {

    private String[] items;
    private Context context;

    public CustomSpinnerAdapter(Context context, int textViewResourceId, String[] items) {
        super(context, textViewResourceId, items);
        this.items = items;
        this.context = context;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View view = super.getDropDownView(position, convertView, parent);

        TextView tv = (TextView) view;
        tv.setTextColor(Color.BLACK); // Set font color in the drop-down list

        return view;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);

        TextView tv = (TextView) view;
        tv.setTextColor(Color.BLACK); // Set the default color of the selected item

        return view;
    }
}
