package ScanCodeUtils;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.basesdkdemo.R;
import com.xuexiang.xqrcode.XQRCode;
import com.xuexiang.xui.utils.XToastUtils;

public class ScanActivity extends Activity {

	private Button scanButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_scan);

		scanButton = findViewById(R.id.scan_button);
		scanButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				test();
			}
		});
	}


	public void test()
	{
		CustomCaptureActivity.start(this, 111, R.style.XQRCodeTheme_Custom);
	}


	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		//������ά��ɨ����
		if (requestCode == 111 && resultCode == RESULT_OK) {
			//����ɨ�������ڽ�������ʾ��
			handleScanResult(data);
		}
	}


	/**
	 * ������ά��ɨ����
	 *
	 * @param data
	 */
	private void handleScanResult(Intent data) {
		if (data != null) {
			Bundle bundle = data.getExtras();
			if (bundle != null) {
				if (bundle.getInt(XQRCode.RESULT_TYPE) == XQRCode.RESULT_SUCCESS) {
					String result = bundle.getString(XQRCode.RESULT_DATA);
					XToastUtils.toast("�������:" + result, Toast.LENGTH_LONG);
				} else if (bundle.getInt(XQRCode.RESULT_TYPE) == XQRCode.RESULT_FAILED) {
					XToastUtils.toast("������ά��ʧ��", Toast.LENGTH_LONG);
				}
			}
		}
	}






}
